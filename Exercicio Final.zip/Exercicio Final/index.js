function renderTransaction(transactionData) { //cria uma transasção com nome, valor e botões para editar e excluir
    const transaction = document.createElement('article')
    transaction.classList.add('transaction')
    transaction.id = `transaction-${transactionData.id}`

    const name = document.createElement('h3')
    name.classList.add('transaction-title')
    name.textContent =`Transação: ${transactionData.name}`

    const val = document.createElement('div')
    val.classList.add('transaction-val')
    val.innerHTML = `Valor: ${transactionData.val}R$`

    const edit = document.createElement('button')
    edit.classList.add('transaction-buttons')
    edit.innerText = "Editar"
    edit.id = transactionData.id

    edit.addEventListener('click',async (ev)=>{ //Evento para editar os valores e nome
        const transactionData = {
            name: document.querySelector('#name').value,
            val: document.querySelector('#val').value,
        }
    
        await fetch(`http://localhost:3000/transactions/${ev.currentTarget.id}`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(transactionData)
        })
        fetchTransaction()
        form.reset()
    })

    const remove = document.createElement('button')
    remove.classList.add('transaction-buttons')
    remove.innerText = "Excluir"
    remove.id = transactionData.id

    remove.addEventListener('click',async (ev)=>{ //Evento para deletar a transação
        await fetch(`http://localhost:3000/transactions/${ev.currentTarget.id}`, {
            method: 'DELETE',
            headers: {
                'Content-Type': 'application/json'
            }
        })
        fetchTransaction()
    })

    transaction.append(name,val, edit, remove)
    document.querySelector('#listTransactions').appendChild(transaction)
}

async function fetchTransaction(){ //Atualizar as transações
    const transactions = await fetch("http://localhost:3000/transactions").then(res => res.json())
    document.querySelector('#listTransactions').innerHTML = ""
    transactions.forEach(renderTransaction);
}

document.addEventListener('DOMContentLoaded', () =>{ //Evento para inicializar
    fetchTransaction()
})

const form = document.querySelector('form')

form.addEventListener('submit',async (ev)=>{ //evento para adicionar uma nova transação quando clicar no botão de submit
    ev.preventDefault()

    const transactionData = {
        name: document.querySelector('#name').value,
        val: document.querySelector('#val').value,
    }

    const response = await fetch('http://localhost:3000/transactions', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(transactionData)
    })

    const savedTransaction = await response.json() //Salva a transação salva e adiciona na tela
    form.reset()
    renderTransaction(savedTransaction)
    console.log(savedTransaction)
})